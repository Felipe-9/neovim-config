return {
  "mg979/vim-visual-multi",
  config = function ()
    vim.g.VM_mouse_mappings = 1
    -- require("vim-visual-multi").setup()
  end
}
