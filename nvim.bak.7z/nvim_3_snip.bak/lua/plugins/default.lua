return {
  "nvim-lua/plenary.nvim",
  "christoomey/vim-tmux-navigator",
}
